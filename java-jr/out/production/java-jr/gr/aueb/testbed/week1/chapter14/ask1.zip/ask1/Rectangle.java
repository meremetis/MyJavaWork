package gr.aueb.testbed.week1.chapter14.ask1;

public class Rectangle extends AbstractShape implements TwoDimensional {
    private double width;
    private double height;

    @Override
    public long getId() {
        return 0;
    }

    @Override
    public double getArea() {
        return 0;
    }
}
