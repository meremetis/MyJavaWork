package gr.aueb.testbed.week1.chapter14.ask1;

public class Circle extends AbstractShape implements TwoDimensional{
    private double radius;

    @Override
    public long getId() {
        return 0;
    }

    @Override
    public double getArea() {
        return 0;
    }
}
