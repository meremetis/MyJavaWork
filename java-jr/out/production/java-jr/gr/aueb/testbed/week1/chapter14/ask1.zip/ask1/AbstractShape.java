package gr.aueb.testbed.week1.chapter14.ask1;

public abstract class AbstractShape implements Ishape {
    private long id;

    public void setId(long id) {
        this.id = id;
    }
}
