package gr.aueb.testbed.week1.chapter14.ask2;

public interface TwoDimensional {
    double getArea();
    long getCircumference();
}
