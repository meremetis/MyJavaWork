package gr.aueb.testbed.week1.chapter14.ask1;

public class Line extends AbstractShape{
    private double length;

    @Override
    public long getId() {
        return 0;
    }
}
