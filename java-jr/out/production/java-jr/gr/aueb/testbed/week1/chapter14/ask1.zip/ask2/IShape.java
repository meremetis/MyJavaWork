package gr.aueb.testbed.week1.chapter14.ask2;

public interface IShape {
    long getId();
}
